package com.marte5.unaduna.model.objects;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="UNADUNA_Chiavi")
public class Chiave {

	private String id;
	private String emailUtente;
	private String chiavePubblica;
	private String chiavePrivata;
	
	/**
	 * @return the codice
	 */
	@DynamoDBHashKey(attributeName="id")
	public String getId() {
		return id;
	}
	/**
	 * @param codice the codice to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * @return the emailUtente
	 */
	@DynamoDBAttribute(attributeName="emailUtente")
	public String getEmailUtente() {
		return emailUtente;
	}
	/**
	 * @param emailUtente the emailUtente to set
	 */
	public void setEmailUtente(String emailUtente) {
		this.emailUtente = emailUtente;
	}
	
	/**
	 * @return the chiavePubblica
	 */
	@DynamoDBAttribute(attributeName="chiavePubblica")
	public String getChiavePubblica() {
		return chiavePubblica;
	}
	/**
	 * @param chiavePubblica the chiavePubblica to set
	 */
	public void setChiavePubblica(String chiavePubblica) {
		this.chiavePubblica = chiavePubblica;
	}
	
	/**
	 * @return the chiavePrivata
	 */
	@DynamoDBAttribute(attributeName="chiavePrivata") 
	public String getChiavePrivata() {
		return chiavePrivata;
	}
	/**
	 * @param chiavePrivata the chiavePrivata to set
	 */
	public void setChiavePrivata(String chiavePrivata) {
		this.chiavePrivata = chiavePrivata;
	}
	
	// - 
	
}

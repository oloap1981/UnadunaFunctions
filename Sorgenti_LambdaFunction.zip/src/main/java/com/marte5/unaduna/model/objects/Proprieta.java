package com.marte5.unaduna.model.objects;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="UNADUNA_Proprieta")
public class Proprieta {

	private String chiave;
	private String valore;
	
	/**
	 * @return the codice
	 */
	@DynamoDBHashKey(attributeName="chiave")
	public String getChiave() {
		return chiave;
	}
	/**
	 * @param codice the codice to set
	 */
	public void setChiave(String chiave) {
		this.chiave = chiave;
	}
	/**
	 * @return the valore
	 */
	@DynamoDBAttribute(attributeName="valore")
	public String getValore() {
		return valore;
	}
	/**
	 * @param valore the valore to set
	 */
	public void setValore(String valore) {
		this.valore = valore;
	}

//
}

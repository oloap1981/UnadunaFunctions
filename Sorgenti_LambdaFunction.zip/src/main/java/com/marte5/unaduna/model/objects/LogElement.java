package com.marte5.unaduna.model.objects;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName="UNADUNA_LogEventi")
public class LogElement {
	
	private long id;
	private String data;
	private String classe;
	private String utente;
	private String messaggio;
	private String tipoLog;

	/**
	 * @return the id
	 */
	@DynamoDBHashKey(attributeName="id")
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the nome
	 */
	//@DynamoDBAttribute(attributeName="nome")
	/**
	 * @return the data
	 */
	@DynamoDBAttribute(attributeName="data")
	public String getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @return the classe
	 */
	@DynamoDBAttribute(attributeName="classe")
	public String getClasse() {
		return classe;
	}
	/**
	 * @param classe the classe to set
	 */
	public void setClasse(String classe) {
		this.classe = classe;
	}
	/**
	 * @return the utente
	 */
	@DynamoDBAttribute(attributeName="utente")
	public String getUtente() {
		return utente;
	}
	/**
	 * @param utente the utente to set
	 */
	public void setUtente(String utente) {
		this.utente = utente;
	}
	/**
	 * @return the messaggio
	 */
	@DynamoDBAttribute(attributeName="messaggio")
	public String getMessaggio() {
		return messaggio;
	}
	/**
	 * @param messaggio the messaggio to set
	 */
	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}
	/**
	 * @return the tipoLog
	 */
	@DynamoDBAttribute(attributeName="tipoLog")
	public String getTipoLog() {
		return tipoLog;
	}
	/**
	 * @param tipoLog the tipoLog to set
	 */
	public void setTipoLog(String tipoLog) {
		this.tipoLog = tipoLog;
	}
	
}

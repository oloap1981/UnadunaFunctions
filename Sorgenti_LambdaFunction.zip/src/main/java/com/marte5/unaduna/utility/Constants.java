package com.marte5.unaduna.utility;

public class Constants {

	public static final String MAIL_FROM_ADDRESS = "UNADUNA_FROM_EMAIL";
	public static final String MAIL_SMTP_SERVER = "UNADUNA_SMTP_SERVER";
	public static final String MAIL_PASSWORD = "Annacloud2019!";
	public static final String MAIL_USER = "info@annacloud.it";
	public static final String MAIL_ALIAS_PASSWORD = "BHLVHto7YzHoLPyxYLOavv+1CJxralKyPEcaS36tvpGr";
	public static final String MAIL_ALIAS_USER = "AKIAJ33EICTMRWYVBSKA";
	public static final String MAIL_PASSWORD_GOOGLE = "Annacloud2019!";
	public static final String MAIL_USER_GOOGLE = "annacloud.ordini@gmail.com";
	//lztnnaowvzycflzv
}

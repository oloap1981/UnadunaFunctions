package requests;

public class UtilFunctionRequest {

	String modello;
	String prefisso;
	String fileName;
	
	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	/**
	 * @return the prefisso
	 */
	public String getPrefisso() {
		return prefisso;
	}

	/**
	 * @param prefisso the prefisso to set
	 */
	public void setPrefisso(String prefisso) {
		this.prefisso = prefisso;
	}

	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
}

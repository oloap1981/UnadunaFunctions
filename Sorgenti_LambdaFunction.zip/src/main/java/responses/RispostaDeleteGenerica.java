package responses;

import com.marte5.unaduna.model.objects.Esito;

public class RispostaDeleteGenerica {
	
	private Esito esito;
	/**
	 * @return the esito
	 */
	public Esito getEsito() {
		return esito;
	}
	/**
	 * @param esito the esito to set
	 */
	public void setEsito(Esito esito) {
		this.esito = esito;
	}	
}

package responses;

import com.marte5.unaduna.model.objects.Esito;

public class RispostaOtherGenerica {
	
	private Esito esito;
	private String imageUrl;
	
	/**
	 * @return the esito
	 */
	public Esito getEsito() {
		return esito;
	}
	/**
	 * @param esito the esito to set
	 */
	public void setEsito(Esito esito) {
		this.esito = esito;
	}
	/**
	 * @return the imageUrl
	 */
	public String getImageUrl() {
		return imageUrl;
	}
	/**
	 * @param imageUrl the imageUrl to set
	 */
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}	
}

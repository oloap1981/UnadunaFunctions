package com.amazonaws.lambda.util.functions;

import java.io.IOException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.marte5.unaduna.handler.common.UnaDunaDelete;
import com.marte5.unaduna.handler.common.UnaDunaGet;

import requests.RichiestaDeleteGenerica;
import requests.RichiestaGetGenerica;
import responses.RispostaDeleteGenerica;
import responses.RispostaGetGenerica;

public class TestDeleteConfigurazione {

	/*
	 * {"functionName":"UnaDunaGetConfigurazioniUtente","codiceUtente":"oloap1981@gmail.com","ifCarrello":false}
	 * */
	private static RichiestaDeleteGenerica input;
	
    @BeforeClass
	public static void createInput() throws IOException {
		input = new RichiestaDeleteGenerica();
		input.setFunctionName("UnaDunaDeleteConfigurazione");
		input.setCodiceConfigurazione("1543584106117");
	}
	
	private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("Your Function Name");

        return ctx;
    }
	
    @Test
    public void testgetModelli() {
        UnaDunaDelete handler = new UnaDunaDelete();
        Context ctx = createContext();

        RispostaDeleteGenerica output = handler.handleRequest(input, ctx);

        // TODO: validate output here if needed.
        Assert.assertEquals("Hello from Lambda!", "");
    }
}



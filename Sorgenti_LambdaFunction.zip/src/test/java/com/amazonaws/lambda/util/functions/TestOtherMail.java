package com.amazonaws.lambda.util.functions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.marte5.unaduna.handler.common.UnaDunaOtherService;

import requests.RichiestaOtherGenerica;
import responses.RispostaOtherGenerica;

public class TestOtherMail {

	private static RichiestaOtherGenerica input;
	
    @BeforeClass
	public static void createInput() throws IOException {
		input = new RichiestaOtherGenerica();
		input.setFunctionName("UnaDunaSendMailGmail");
		/*		String mailMessage = request.getEmailMessage();
		String subject = request.getEmailSubject();
		List<String> toAddressList = request.getToEmailAdresses();
		List<String> ccAddressList = request.getCcEmailAdresses();*/
		
		input.setEmailMessage("Messaggio di test");
		input.setEmailSubject("Test Subject");
		List<String> lista = new ArrayList<>();
		lista.add("oloap1981@gmail.com");
		input.setToEmailAdresses(lista);
	}
	
	private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("Your Function Name");

        return ctx;
    }
	
    @Test
    public void testputConfigurazione() {
        UnaDunaOtherService handler = new UnaDunaOtherService();
        Context ctx = createContext();

        RispostaOtherGenerica output = handler.handleRequest(input, ctx);

        // TODO: validate output here if needed.
        Assert.assertEquals("Hello from Lambda!", "");
    }
}



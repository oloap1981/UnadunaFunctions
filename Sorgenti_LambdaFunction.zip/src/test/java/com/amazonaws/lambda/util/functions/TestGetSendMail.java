package com.amazonaws.lambda.util.functions;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.marte5.unaduna.handler.common.UnaDunaOtherService;

import requests.RichiestaOtherGenerica;
import responses.RispostaOtherGenerica;

public class TestGetSendMail {

	/*
	 * {"functionName":"UnaDunaGetConfigurazioniUtente","codiceUtente":"oloap1981@gmail.com","ifCarrello":false}
	 * */
	private static RichiestaOtherGenerica input;
	
    @BeforeClass
	public static void createInput() throws IOException {
		input = new RichiestaOtherGenerica();
		input.setFunctionName("UnaDunaSendMail");
		input.setEmailMessage("Prova messaggio ");
		input.setEmailSubject("Prova Subject");
		
		ArrayList<String> toAddresses = new ArrayList<>();
		toAddresses.add("oloap1981@gmail.com");
		
		input.setToEmailAdresses(toAddresses);
		
	}
	
	private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("Your Function Name");

        return ctx;
    }
	
    @Test
    public void testgetModelli() {
        UnaDunaOtherService handler = new UnaDunaOtherService();
        Context ctx = createContext();

        handler.handleRequest(input, ctx);

        // TODO: validate output here if needed.
        Assert.assertEquals("Hello from Lambda!", "");
    }
}



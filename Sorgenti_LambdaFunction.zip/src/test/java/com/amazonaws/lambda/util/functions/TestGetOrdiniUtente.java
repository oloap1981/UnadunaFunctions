package com.amazonaws.lambda.util.functions;

import java.io.IOException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.marte5.unaduna.handler.common.UnaDunaGet;

import requests.RichiestaGetGenerica;
import responses.RispostaGetGenerica;

public class TestGetOrdiniUtente {

	private static RichiestaGetGenerica input;
	
    @BeforeClass
	public static void createInput() throws IOException {
		input = new RichiestaGetGenerica();
		input.setFunctionName("UnaDunaGetOrdiniUtente");
		input.setEmailUtente("oloap1981@gmail.com");
	}
	
	private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("Your Function Name");

        return ctx;
    }
	
    @Test
    public void testgetModelli() {
        UnaDunaGet handler = new UnaDunaGet();
        Context ctx = createContext();

        RispostaGetGenerica output = handler.handleRequest(input, ctx);

        // TODO: validate output here if needed.
        Assert.assertEquals("Hello from Lambda!", output.getModelli().size());
    }
}



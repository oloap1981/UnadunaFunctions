package com.amazonaws.lambda.util.functions;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.amazonaws.services.lambda.runtime.Context;
import com.marte5.unaduna.handler.common.UnaDunaPut;
import com.marte5.unaduna.model.objects.Configurazione;
import com.marte5.unaduna.model.objects.Configurazione.Entita;
import com.marte5.unaduna.model.objects.Configurazione.UtenteConfigurazione;

import requests.RichiestaPutGenerica;
import responses.RispostaPutGenerica;

public class TestPutConfigurazione {

	private static RichiestaPutGenerica input;
	
    @BeforeClass
	public static void createInput() throws IOException {
		input = new RichiestaPutGenerica();
		input.setFunctionName("UnaDunaPutConfigurazione");
		
		Configurazione conf = new Configurazione();
		conf.setCarrello(true);
		conf.setCodice("");
		conf.setDedica("");
		conf.setNome("");
		
		UtenteConfigurazione utente = new UtenteConfigurazione();
		utente.setEmail("oloap1981@gmail.com");
		
		ArrayList<Entita> elencoEntita = new ArrayList<>();
		conf.setElencoEntita(elencoEntita);
		
		input.setConfigurazione(conf);
		
	}
	
	private Context createContext() {
        TestContext ctx = new TestContext();

        // TODO: customize your context here if needed.
        ctx.setFunctionName("Your Function Name");

        return ctx;
    }
	
    @Test
    public void testputConfigurazione() {
        UnaDunaPut handler = new UnaDunaPut();
        Context ctx = createContext();

        RispostaPutGenerica output = handler.handleRequest(input, ctx);

        // TODO: validate output here if needed.
        Assert.assertEquals("Hello from Lambda!", "");
    }
}


